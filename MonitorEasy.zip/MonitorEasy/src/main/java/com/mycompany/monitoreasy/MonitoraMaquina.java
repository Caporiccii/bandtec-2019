package com.mycompany.monitoreasy;

import oshi.SystemInfo;
import oshi.hardware.CentralProcessor;
import oshi.hardware.GlobalMemory;
import oshi.hardware.HardwareAbstractionLayer;
import oshi.software.os.OperatingSystem;
import oshi.util.FormatUtil;

public class MonitoraMaquina {

    SystemInfo sistemaInfo = new SystemInfo();
    OperatingSystem os = sistemaInfo.getOperatingSystem();
    HardwareAbstractionLayer hardwareAbstracao = sistemaInfo.getHardware();
    long memoriaDisponivel;
    long memoriaTotal;
    String monitorMemoria;
    String processoTotal;
    public String getMemory(GlobalMemory memoria) {

        memoriaDisponivel = memoria.getAvailable();
        memoriaTotal = memoria.getTotal();

        monitorMemoria = String.format("Total:%s Disponivel:%s",
                        FormatUtil.formatBytes(memoriaTotal),
                        FormatUtil.formatBytes(memoriaDisponivel));
        return monitorMemoria;
    }
    
    public String getProcessor (CentralProcessor processos){
        long[] processadorAtual = hardwareAbstracao.getProcessor().getSystemCpuLoadTicks();
        
        
        
        
    return processoTotal;
    }
    
    

}
